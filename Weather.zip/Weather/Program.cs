﻿
using System.Text.Json;
 
namespace Weather
{
        public class CurrentWeather
    {
        public double temperature { get; set; }
        public double windspeed { get; set; }
        public double winddirection { get; set; }
        public int weathercode { get; set; }
        public int is_day { get; set; }
        public string time { get; set; }
    }
    public class Root
    {
        public double latitude { get; set; }
        public double longitude { get; set; }
        public double generationtime_ms { get; set; }
        public int utc_offset_seconds { get; set; }
        public string timezone { get; set; }
        public string timezone_abbreviation { get; set; }
        public double elevation { get; set; }
        public CurrentWeather current_weather { get; set; }

    }
    public class CityData
    {
        public string city { get; set; }
        public string lat { get; set; }
        public string lng { get; set; }
    }
    class Program
    {
        static async Task Main(string[] args)
        {

            // Load city data from file or data storage
            string filePath = @"C:\Dotnet\Weather\City\city_data.json";
            List<CityData> cityData = LoadCityDataFromFile(filePath);


            Console.WriteLine("Enter the name of the city:");
            string? cityName = Console.ReadLine();
            if (cityName is null)
            {
                System.Console.WriteLine("Invalid input. City name cannot be null.");
                return;
            }

            //Find the city by name
            CityData? selectedCity = cityData.FirstOrDefault(c => c.city.Equals(cityName, StringComparison.OrdinalIgnoreCase));
            if (selectedCity == null)
            {
                Console.WriteLine("City not found.");
                return;
            }

            //Prepare the API URL for weather data
            string weatherApiUrl = $"https://api.open-meteo.com/v1/forecast?latitude={selectedCity.lat}&longitude={selectedCity.lng}&current_weather=true";

            using (HttpClient client = new HttpClient())
            {
                // Fetch weather data for the given latitude and longitude
                string weatherData = await client.GetStringAsync(weatherApiUrl);

                //Deserialize the weather data
                Root weather = JsonSerializer.Deserialize<Root>(weatherData);

                //Display the weather data
                Console.WriteLine($"City: {cityName}");
                Console.WriteLine($"Temperature: {weather.current_weather.temperature}°C");
                Console.WriteLine($"Wind Speed: {weather.current_weather.windspeed} m/s");
                Console.WriteLine($"Wind Direction: {weather.current_weather.winddirection}°");
                Console.WriteLine($"Weather Code: {weather.current_weather.weathercode}");
                Console.WriteLine($"Time: {weather.current_weather.time}");

            }

        }
        static List<CityData> LoadCityDataFromFile(string filePath)

        {

            List<CityData> cityData = new List<CityData>();
            try
            {
                //Read the JSON data from the file
                string jsonData = File.ReadAllText(filePath);

                //Deserialize the JSON data into a list of CityData objects
                cityData = JsonSerializer.Deserialize<List<CityData>>(jsonData) ?? new List<CityData>();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error loading city data: {ex.Message}");
            }

            return cityData;
        }
     }
}


 